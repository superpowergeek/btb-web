import { GetUserQuery } from '@onextech/etc-api'

export type UserInterface = GetUserQuery['getUser']
