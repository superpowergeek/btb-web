export { default as useLazyListDiscounts } from './useLazyListDiscounts'
