// To use when attempting to list all records in list queries
export const DEFAULT_LIMIT = 999
