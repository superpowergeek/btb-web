const routes = {
  '/management': 'Management',
  '/management/performance': 'Performance',
  '/management/risk-manager': 'RiskManager',
}

export default routes
